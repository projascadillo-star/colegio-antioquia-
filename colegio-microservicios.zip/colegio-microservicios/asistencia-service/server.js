// ═══════════════════════════════════════════════════════════════
// ASISTENCIA-SERVICE
// Dueño único de la tabla registro_asistencia.
// ═══════════════════════════════════════════════════════════════
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(express.json());

const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);
const norm = v => (v !== null && v !== undefined ? String(v) : null);

// GET /asistencia?estudianteIds=1,2,3&fecha=2026-07-07
app.get('/asistencia', async (req, res) => {
  const { estudianteIds, fecha } = req.query;
  if (!estudianteIds) return res.status(400).json({ error: 'estudianteIds es requerido' });

  let q = sb.from('registro_asistencia').select('*').in('estudiante_id', estudianteIds.split(','));
  if (fecha) q = q.eq('fecha', fecha);
  const { data, error } = await q;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Historial de un solo estudiante (para "Mi asistencia" / libreta)
app.get('/asistencia/estudiante/:id', async (req, res) => {
  const { data, error } = await sb
    .from('registro_asistencia')
    .select('*')
    .eq('estudiante_id', norm(req.params.id))
    .order('fecha', { ascending: false });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Guardado masivo: [{ estudiante_id, fecha, estado, justificado, motivo_justificacion, docente_id }]
app.post('/asistencia', async (req, res) => {
  const filas = req.body.registros || [];
  try {
    for (const f of filas) {
      const { data: exist } = await sb
        .from('registro_asistencia')
        .select('id')
        .eq('estudiante_id', f.estudiante_id)
        .eq('fecha', f.fecha)
        .single();

      if (exist) {
        await sb
          .from('registro_asistencia')
          .update({
            estado: f.estado,
            justificado: f.justificado,
            motivo_justificacion: f.motivo_justificacion,
            docente_id: f.docente_id,
          })
          .eq('id', norm(exist.id));
      } else {
        await sb.from('registro_asistencia').insert(f);
      }
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'asistencia-service' }));

const PORT = process.env.PORT || 3004;
app.listen(PORT, () => console.log(`asistencia-service escuchando en puerto ${PORT}`));
