// ═══════════════════════════════════════════════════════════════
// AUTH-SERVICE
// Único servicio que toca sb.auth. Responsable exclusivo de
// login, logout y verificación de sesión.
// ═══════════════════════════════════════════════════════════════
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(express.json());

const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);

const norm = v => (v !== null && v !== undefined ? String(v) : null);

// POST /login  { correo, pass }
app.post('/login', async (req, res) => {
  const { correo, pass } = req.body;
  if (!correo || !pass) {
    return res.status(400).json({ error: 'Ingresa correo y contraseña' });
  }

  try {
    // 1. Supabase Auth verifica email + contraseña con bcrypt de forma segura
    const { data: authData, error: authError } = await sb.auth.signInWithPassword({
      email: correo,
      password: pass,
    });

    if (authError) {
      if (authError.message.includes('Invalid login')) {
        return res.status(401).json({ error: 'Correo o contraseña incorrectos' });
      }
      if (authError.message.includes('Email not confirmed')) {
        return res.status(401).json({ error: 'Debes confirmar tu correo antes de ingresar' });
      }
      return res.status(401).json({ error: 'Error al iniciar sesión: ' + authError.message });
    }

    // 2. Obtener el perfil del usuario desde la tabla usuarios
    const authUid = authData.user.id;
    const { data: userRow, error: userError } = await sb
      .from('usuarios')
      .select('*')
      .eq('auth_id', authUid)
      .eq('activo', true)
      .single();

    if (userError || !userRow) {
      await sb.auth.signOut();
      return res.status(404).json({ error: 'Usuario no encontrado o inactivo. Contacta al administrador.' });
    }

    // 3. Cargar perfil extendido según rol
    let perfil = null;
    if (userRow.rol === 'DOCENTE') {
      const { data } = await sb.from('docentes').select('*').eq('usuario_id', norm(userRow.id)).single();
      perfil = data;
    } else if (userRow.rol === 'ESTUDIANTE') {
      const { data } = await sb
        .from('estudiantes')
        .select('*, secciones(nombre, grado)')
        .eq('usuario_id', norm(userRow.id))
        .single();
      perfil = data;
    } else if (userRow.rol === 'PADRE_FAMILIA') {
      const { data } = await sb
        .from('padres_familia')
        .select('*, estudiantes(nombre,apellido,grado)')
        .eq('usuario_id', norm(userRow.id))
        .single();
      perfil = data;
    }

    // 4. Devolver usuario + perfil + tokens de sesión al frontend
    //    El frontend guarda estos tokens (sessionStorage) y los manda
    //    como "Authorization: Bearer <access_token>" en cada request
    //    a los demás microservicios.
    res.json({
      user: userRow,
      perfil,
      session: {
        access_token: authData.session.access_token,
        refresh_token: authData.session.refresh_token,
      },
    });
  } catch (e) {
    res.status(500).json({ error: 'Error de conexión: ' + e.message });
  }
});

// POST /logout — requiere header Authorization: Bearer <access_token>
app.post('/logout', async (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token) {
    // Invalida la sesión asociada a ese token
    await sb.auth.signOut({ scope: 'local' }).catch(() => {});
  }
  res.json({ ok: true });
});

// GET /session — valida el token y devuelve el usuario. Lo usan los
// demás microservicios (o el gateway) para verificar quién hace la petición.
app.get('/session', async (req, res) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Sin token' });

  const { data: { user }, error } = await sb.auth.getUser(token);
  if (error || !user) return res.status(401).json({ error: 'Sesión inválida o expirada' });

  const { data: userRow } = await sb.from('usuarios').select('*').eq('auth_id', user.id).single();
  if (!userRow) return res.status(404).json({ error: 'Usuario no encontrado' });

  res.json({ user: userRow });
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'auth-service' }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`auth-service escuchando en puerto ${PORT}`));
