// ═══════════════════════════════════════════════════════════════
// API GATEWAY
// Único punto de entrada del frontend. Enruta cada petición al
// microservicio dueño de ese dominio. También compone respuestas
// que necesitan datos de más de un servicio (ej: la libreta).
// ═══════════════════════════════════════════════════════════════
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
app.use(cors());

const AUTH = process.env.AUTH_SERVICE_URL || 'http://localhost:3001';
const USUARIOS = process.env.USUARIOS_SERVICE_URL || 'http://localhost:3002';
const NOTAS = process.env.NOTAS_SERVICE_URL || 'http://localhost:3003';
const ASISTENCIA = process.env.ASISTENCIA_SERVICE_URL || 'http://localhost:3004';

// ── Ruteo directo: el gateway solo reenvía la petición tal cual ──
app.use('/auth', createProxyMiddleware({ target: AUTH, changeOrigin: true, pathRewrite: { '^/auth': '' } }));
app.use('/usuarios', createProxyMiddleware({ target: USUARIOS, changeOrigin: true, pathRewrite: { '^/usuarios': '' } }));
app.use('/notas', createProxyMiddleware({ target: NOTAS, changeOrigin: true, pathRewrite: { '^/notas': '' } }));
app.use('/asistencia', createProxyMiddleware({ target: ASISTENCIA, changeOrigin: true, pathRewrite: { '^/asistencia': '' } }));

// A partir de aquí sí necesitamos leer el body (rutas propias del gateway)
app.use(express.json());

// ── Composición: la libreta necesita usuarios + notas + asistencia ──
// Esto es lo que en microservicios se llama un "BFF" (Backend For
// Frontend): el gateway llama a 3 servicios distintos y arma UNA
// respuesta para que el frontend no tenga que hacer 3 llamadas.
app.get('/libreta/:estudianteId', async (req, res) => {
  const estId = req.params.estudianteId;
  try {
    const [estRes, cbRes, cfRes, asistRes] = await Promise.all([
      fetch(`${USUARIOS}/estudiantes/${estId}`),
      fetch(`${NOTAS}/calificativo-bimestral?estudianteId=${estId}`),
      fetch(`${NOTAS}/calificativo-final?estudianteId=${estId}`),
      fetch(`${ASISTENCIA}/asistencia/estudiante/${estId}`),
    ]);

    const [est, cb, cf, asist] = await Promise.all([
      estRes.json(),
      cbRes.json(),
      cfRes.json(),
      asistRes.json(),
    ]);

    res.json({ est, cb, cf, asist });
  } catch (e) {
    res.status(500).json({ error: 'Error al componer la libreta: ' + e.message });
  }
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'gateway' }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`gateway escuchando en puerto ${PORT}`));
