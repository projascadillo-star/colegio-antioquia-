// ═══════════════════════════════════════════════════════════════
// NOTAS-SERVICE
// Dueño de: evaluaciones, nota_evaluacion, calificativo_bimestral,
// calificativo_final. NO toca la tabla de asistencia — eso es
// responsabilidad exclusiva de asistencia-service (así se ven las
// fronteras de dominio en microservicios).
// ═══════════════════════════════════════════════════════════════
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(express.json());

const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY);
const norm = v => (v !== null && v !== undefined ? String(v) : null);

// ── EVALUACIONES ─────────────────────────────────────────────
app.get('/evaluaciones', async (req, res) => {
  const { docenteId } = req.query;
  if (!docenteId) return res.status(400).json({ error: 'docenteId es requerido' });

  const { data, error } = await sb
    .from('evaluaciones')
    .select('*, competencias(nombre,cursos(nombre)), bimestres(numero,estado,ano_escolar(anio))')
    .eq('docente_id', docenteId)
    .order('fecha', { ascending: false });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/evaluaciones', async (req, res) => {
  const { data, error } = await sb.from('evaluaciones').insert(req.body).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

// ── NOTAS DE UNA EVALUACIÓN ──────────────────────────────────
app.get('/evaluaciones/:id/notas', async (req, res) => {
  const { data, error } = await sb.from('nota_evaluacion').select('*').eq('evaluacion_id', req.params.id);
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Guardado masivo: [{ estudiante_id, calificativo, observacion }]
app.post('/evaluaciones/:id/notas', async (req, res) => {
  const evaluacionId = req.params.id;
  const filas = req.body.notas || [];
  try {
    for (const fila of filas) {
      const { data: exist } = await sb
        .from('nota_evaluacion')
        .select('id')
        .eq('evaluacion_id', evaluacionId)
        .eq('estudiante_id', fila.estudiante_id)
        .single();

      if (exist) {
        await sb
          .from('nota_evaluacion')
          .update({ calificativo: fila.calificativo, observacion: fila.observacion })
          .eq('id', norm(exist.id));
      } else {
        await sb.from('nota_evaluacion').insert({ ...fila, evaluacion_id: evaluacionId });
      }
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── CALIFICATIVO BIMESTRAL ───────────────────────────────────
app.get('/calificativo-bimestral', async (req, res) => {
  const { estudianteId, bimestreId, docenteId } = req.query;
  let q = sb.from('calificativo_bimestral').select('*, competencias(nombre,cursos(nombre)), bimestres(numero)');
  if (estudianteId) q = q.eq('estudiante_id', estudianteId);
  if (bimestreId) q = q.eq('bimestre_id', bimestreId);
  if (docenteId) q = q.eq('docente_id', docenteId);
  const { data, error } = await q;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Guardado masivo: [{ estudiante_id, competencia_id, bimestre_id, calificativo, docente_id }]
app.post('/calificativo-bimestral', async (req, res) => {
  const filas = req.body.calificativos || [];
  try {
    for (const f of filas) {
      const { data: exist } = await sb
        .from('calificativo_bimestral')
        .select('id')
        .eq('estudiante_id', f.estudiante_id)
        .eq('competencia_id', f.competencia_id)
        .eq('bimestre_id', f.bimestre_id)
        .single();

      if (exist) {
        await sb
          .from('calificativo_bimestral')
          .update({ calificativo: f.calificativo, docente_id: f.docente_id })
          .eq('id', norm(exist.id));
      } else {
        await sb.from('calificativo_bimestral').insert(f);
      }
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── CALIFICATIVO FINAL ───────────────────────────────────────
app.get('/calificativo-final', async (req, res) => {
  const { estudianteId, anoId, docenteId } = req.query;
  let q = sb.from('calificativo_final').select('*, competencias(nombre,cursos(nombre)), ano_escolar(anio)');
  if (estudianteId) q = q.eq('estudiante_id', estudianteId);
  if (anoId) q = q.eq('ano_escolar_id', anoId);
  if (docenteId) q = q.eq('docente_id', docenteId);
  const { data, error } = await q;
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/calificativo-final', async (req, res) => {
  const filas = req.body.calificativos || [];
  try {
    for (const f of filas) {
      const { data: exist } = await sb
        .from('calificativo_final')
        .select('id')
        .eq('estudiante_id', f.estudiante_id)
        .eq('competencia_id', f.competencia_id)
        .eq('ano_escolar_id', f.ano_escolar_id)
        .single();

      if (exist) {
        await sb
          .from('calificativo_final')
          .update({ calificativo: f.calificativo, docente_id: f.docente_id })
          .eq('id', norm(exist.id));
      } else {
        await sb.from('calificativo_final').insert(f);
      }
    }
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'notas-service' }));

const PORT = process.env.PORT || 3003;
app.listen(PORT, () => console.log(`notas-service escuchando en puerto ${PORT}`));
