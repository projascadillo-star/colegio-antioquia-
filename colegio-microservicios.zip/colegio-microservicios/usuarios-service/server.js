// ═══════════════════════════════════════════════════════════════
// USUARIOS-SERVICE
// Dueño de las tablas: usuarios, estudiantes, docentes, secciones,
// padres_familia. Es el único servicio que las escribe.
//
// NOTA IMPORTANTE: usa la SERVICE ROLE key porque crea cuentas de
// Auth (sb.auth.admin.createUser). En tu código original esto se
// hacía desde el navegador con sb.auth.signUp / sb.auth.admin — eso
// solo funciona si expusiste la service role key en el frontend,
// lo cual es un riesgo de seguridad real. Moverlo aquí lo arregla.
// ═══════════════════════════════════════════════════════════════
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(express.json());

const sb = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
const norm = v => (v !== null && v !== undefined ? String(v) : null);

// ── ESTUDIANTES ──────────────────────────────────────────────
app.get('/estudiantes', async (req, res) => {
  const { data, error } = await sb
    .from('estudiantes')
    .select('*, secciones(nombre,grado), usuarios(correo,activo)')
    .order('apellido');
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/estudiantes', async (req, res) => {
  const { correo, pass, ...payload } = req.body;
  try {
    // 1. Crear cuenta de Auth
    const { data: authData, error: authError } = await sb.auth.admin.createUser({
      email: correo,
      password: pass,
      email_confirm: true,
    });
    if (authError) return res.status(400).json({ error: authError.message });

    // 2. Crear fila en usuarios
    const { data: user, error: ue } = await sb
      .from('usuarios')
      .insert({ correo, rol: 'ESTUDIANTE', auth_id: authData.user.id, activo: true })
      .select()
      .single();
    if (ue) {
      await sb.auth.admin.deleteUser(authData.user.id);
      return res.status(400).json({ error: ue.message });
    }

    // 3. Crear fila en estudiantes
    const { data: est, error: ee } = await sb
      .from('estudiantes')
      .insert({ ...payload, usuario_id: norm(user.id) })
      .select()
      .single();
    if (ee) {
      await sb.auth.admin.deleteUser(authData.user.id);
      return res.status(400).json({ error: ee.message });
    }

    res.status(201).json(est);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/estudiantes/:id', async (req, res) => {
  const { error } = await sb.from('estudiantes').update(req.body).eq('id', norm(req.params.id));
  if (error) return res.status(400).json({ error: error.message });
  res.json({ ok: true });
});

app.delete('/estudiantes/:id', async (req, res) => {
  const { error } = await sb.from('estudiantes').delete().eq('id', norm(req.params.id));
  if (error) return res.status(400).json({ error: error.message });
  res.json({ ok: true });
});

// ── DOCENTES ──────────────────────────────────────────────────
app.get('/docentes', async (req, res) => {
  const { data, error } = await sb.from('docentes').select('*, usuarios(correo,activo)').order('apellido');
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/docentes', async (req, res) => {
  const { correo, pass, ...payload } = req.body;
  try {
    const { data: authData, error: authError } = await sb.auth.admin.createUser({
      email: correo,
      password: pass,
      email_confirm: true,
    });
    if (authError) return res.status(400).json({ error: authError.message });

    const { data: user, error: ue } = await sb
      .from('usuarios')
      .insert({ correo, rol: 'DOCENTE', auth_id: authData.user.id, activo: true })
      .select()
      .single();
    if (ue) {
      await sb.auth.admin.deleteUser(authData.user.id);
      return res.status(400).json({ error: ue.message });
    }

    const { data: doc, error: de } = await sb
      .from('docentes')
      .insert({ ...payload, usuario_id: norm(user.id) })
      .select()
      .single();
    if (de) {
      await sb.auth.admin.deleteUser(authData.user.id);
      return res.status(400).json({ error: de.message });
    }

    res.status(201).json(doc);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/docentes/:id', async (req, res) => {
  const { error } = await sb.from('docentes').update(req.body).eq('id', norm(req.params.id));
  if (error) return res.status(400).json({ error: error.message });
  res.json({ ok: true });
});

// ── SECCIONES ─────────────────────────────────────────────────
app.get('/secciones', async (req, res) => {
  const { data, error } = await sb.from('secciones').select('*, ano_escolar(anio)').order('grado');
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/secciones', async (req, res) => {
  const { data, error } = await sb.from('secciones').insert(req.body).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

app.put('/secciones/:id', async (req, res) => {
  const { error } = await sb.from('secciones').update(req.body).eq('id', norm(req.params.id));
  if (error) return res.status(400).json({ error: error.message });
  res.json({ ok: true });
});

// Datos básicos de un estudiante (usado por notas-service/gateway para armar la libreta)
app.get('/estudiantes/:id', async (req, res) => {
  const { data, error } = await sb
    .from('estudiantes')
    .select('*, secciones(nombre,grado)')
    .eq('id', norm(req.params.id))
    .single();
  if (error) return res.status(404).json({ error: error.message });
  res.json(data);
});

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'usuarios-service' }));

const PORT = process.env.PORT || 3002;
app.listen(PORT, () => console.log(`usuarios-service escuchando en puerto ${PORT}`));
